import requests,numpy,xlsxwriter
from bs4 import BeautifulSoup

def main():
    
    # 創建Excel存放資料   
    workbook = xlsxwriter.Workbook('PCGO.xlsx')
    worksheet = workbook.add_worksheet()
    row = 1
    row2 = 26
    row3 = 26
    row4 = 26
    worksheet.write(0, 0, '標題')
    worksheet.write(0, 1, '日期出處')
    worksheet.write(0, 2, '內文')
    
    article = '' #存放文章內文
    source = '文章出處'
    
    print('')
    print('----------爬蟲開始----------')
    file = open('PCGO.txt')
    for line in file:
        x = line.strip() #去掉頭尾空白
        
        # 判斷出處        
        if x[0:1] == '!':
            source = '空白'
        elif x[11:21] == 'chinatimes':
            source = '中時電子報'
        elif x[8:13] == 'money':
            source = '經濟日報'
        elif x[8:11] == 'udn':
            source = '聯合新聞網'
        elif x[8:16] == 'technews':
            source = '科技新報'

        if source != '空白':
            resp = requests.get(x)
            soup = BeautifulSoup(resp.text, 'html.parser')
        
        if source == '空白':
            worksheet.write(row, 0, '標題')
            worksheet.write(row2, 0, '標題')
            row += 1
            row2 += 1
            print('標題')
            
            worksheet.write(row3, 1, '日期來源')
            row3 += 1
            
            worksheet.write(row4, 2, '本篇標記無法爬蟲，網址為：'+x[1:])
            row4 += 1   
            print('本篇標記無法爬蟲，網址為：'+x[1:])
        elif source == '中時電子報':
            # 抓標題
            main_titles = soup.find(id="h1")
            for title in main_titles:
                title = title.strip() #去掉頭尾空白 
                print(title)
                worksheet.write(row, 0, title)
                worksheet.write(row2, 0, title)
                row += 1
                row2 += 1

            # 抓日期+來源
            main_titles = soup.article.find_all('time')
            for title in main_titles:
                title = title.text.strip() #去掉頭尾空白 
                title = title.replace("年", "/") #替換年月成斜線 
                title = title.replace("月", "/") #替換年月成斜線
                title = title[:10]+' '+source
                print(title)
                worksheet.write(row3, 1, title)
                row3 += 1

            # 抓內文
            main_titles = soup.article.find_all('p')
            for title in main_titles:
                if title.text!='(工商時報)':
                    article += title.text
                    article += '\r\t' #加上換行和縮排
            worksheet.write(row4, 2, article)
            row4 += 1
            article = ''
        elif source == '經濟日報':
            # 抓標題
            main_titles = soup.find(id="story_art_title")
            for title in main_titles:
                title = title.strip() #去掉頭尾空白 
                print(title)
                worksheet.write(row, 0, title)
                worksheet.write(row2, 0, title)
                row += 1
                row2 += 1

            # 抓日期+來源
            main_titles = soup.select('.shareBar__info--author span')
            for title in main_titles:
                title = title.text.strip() #去掉頭尾空白 
                title = title.replace("-", "/") #替換年月成斜線 
                title = title.replace("-", "/") #替換年月成斜線
                title = title[:10]+' '+source
                print(title)
                worksheet.write(row3, 1, title)
                row3 += 1

            # 抓內文
            main_titles = soup.select('#story_body_content p')
            for title in main_titles:
                article += title.text
                article += '\t' #加上換行和縮排
            worksheet.write(row4, 2, article)
            row4 += 1
            article = ''
#             worksheet.write(row4, 2, '經濟日報暫時無法爬蟲，網址為：'+x)
#             row4 += 1
        elif source == '聯合新聞網':
            # 抓標題
            main_titles = soup.find(id="story_art_title")
            for title in main_titles:
                title = title.strip() #去掉頭尾空白 
                print(title)
                worksheet.write(row, 0, title)
                worksheet.write(row2, 0, title)
                row += 1
                row2 += 1
            
            # 抓日期+來源
            main_titles = soup.select('.story_bady_info_author span')
            for title in main_titles:
                title = title.text.strip() #去掉頭尾空白 
                title = title.replace("-", "/") #替換年月成斜線 
                title = title.replace("-", "/") #替換年月成斜線
                title = title[:10]+' '+source
                print(title)
                worksheet.write(row3, 1, title)
                row3 += 1
        
            # 抓內文
            main_titles = soup.select('#story_body_content p')
            for title in main_titles:
                if title.text != "" :
                    article += title.text
                    article += '\r\t' #加上換行和縮排
            worksheet.write(row4, 2, article)
            row4 += 1
            article = ''
        elif source == '科技新報':
            # 抓標題
            main_titles = soup.select('.entry-title a')
            for title in main_titles:
                print(title.text)
                worksheet.write(row, 0, title.text)
                worksheet.write(row2, 0, title.text)
                row += 1
                row2 += 1

            # 抓日期+來源
            main_titles = soup.select('.body')[1]
            for title in main_titles:
                title = title.replace(" ", "") #把空格刪掉 
                title = title.replace("年", "/") #替換年月成斜線 
                title = title.replace("月", "/") #替換年月成斜線
                title = title[:10]+' '+source
                print(title)
                worksheet.write(row3, 1, title)
                row3 += 1
            
            # 抓內文
            main_titles = soup.select('.indent p')
            for title in main_titles:
                if title.text != "" :
                    article += title.text
                    article += '\n' #加上換行
            worksheet.write(row4, 2, article)
            row4 += 1
            article = ''
            
    file.close()
    workbook.close()
    print('----------爬蟲結束----------')

if __name__ == '__main__':
    main()