# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.keys import Keys  
from time import sleep
from bs4 import BeautifulSoup

driver = webdriver.Chrome('/Users/Dole_TW/chromedriver')
driver.get('http://www.mii-mirdc.tw/admin/login.asp')

driver.find_element_by_name("loginname").send_keys("shadowwho")
driver.find_element_by_name("loginpwd").send_keys("1234567")
driver.find_element_by_xpath("//input[@value='登入']").click()
sleep(1)
driver.get('http://www.mii-mirdc.tw/admin/researchprocess/researchplan_list.asp')

print('-------------------以下為題目＋狀態-------------------')
c="" 
file = open('RYGO.txt') 
for line in file:
    titleText = line.strip()
    driver.find_element_by_name("keyword").click()
    driver.find_element_by_name("keyword").clear()
    driver.find_element_by_name("keyword").send_keys(titleText)
    driver.find_element_by_xpath("//a/font").click()
    driver.find_element_by_link_text(titleText).click()


    soup = BeautifulSoup(driver.page_source,'html.parser')
    # 抓表格
    a=0
    for title in soup.select('#table5 tbody tr .lf_td1'):
        a=a+1
    b=""
    for title in soup.select('#table5 tbody tr .lf_td1')[a-3]:
        b=b+str(str(title).strip())
    if b.find('出版')!=-1:
        print(titleText+" 【已結案】")
        c=c+"已結案\n"
    elif b.find('退')!=-1:
        print(titleText+" 【退稿】")
        c=c+"退稿\n"        
    elif b.find('審稿')!=-1:
        print(titleText+" 【審稿】")
        c=c+"審稿\n"        
    elif b.find('校稿')!=-1:
        print(titleText+" 【校稿】")
        c=c+"校稿\n"        
    else:
        print(titleText+" 【未上傳】")
        c=c+"未上傳\n"        
    driver.back()
print('-------------------以下僅狀態，方便複製-------------------')    
print(c)
driver.close()