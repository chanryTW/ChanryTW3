import requests,numpy
from bs4 import BeautifulSoup

def main():
    
    print('')        
    print('-------------------以下為中國時報-------------------')    
    file = open('中國時報.txt')
    for line in file:
        x = line.strip() #去掉頭尾空白
    
        resp = requests.get(x)
        soup = BeautifulSoup(resp.text, 'html.parser')
        # 抓標題
        main_titles = soup.find(id="h1")
        for title in main_titles:
            title = title.strip() #去掉頭尾空白 
            print('')
            print(title)
            print('')
        # 抓內文第一段
        main_titles = soup.article.find_all('p')[0]
        for title in main_titles:
            print('<strong><span style="color:#000000;font-family: 標楷體; font-size: 18px;">'+title+'</span></strong><span style="color:#000000;font-family: 標楷體; font-size: 20px;"><br /><br /><a href="'+x+'">資料來源:<span style=font-family: Times New Roman;>'+x+'</span></a></span>')
    file.close()

    print('')    
    print('-------------------以下為經濟日報-------------------')
    file = open('經濟日報.txt')
    for line in file:
        x = line.strip() #去掉頭尾空白
    
        resp = requests.get(x)
        soup = BeautifulSoup(resp.text, 'html.parser')
        # 抓標題
        main_titles = soup.find(id="story_art_title")
        for title in main_titles:
            print('')
            print(title)
            print('')
        # 抓內文第一段
        main_titles = soup.find_all('p')[1]
        for title in main_titles:
            print('<strong><span style="color:#000000;font-family: 標楷體; font-size: 18px;">'+title+'</span></strong><span style="color:#000000;font-family: 標楷體; font-size: 20px;"><br /><br /><a href="'+x+'">資料來源:<span style=font-family: Times New Roman;>'+x+'</span></a></span>')
    file.close()

if __name__ == '__main__':
    main()